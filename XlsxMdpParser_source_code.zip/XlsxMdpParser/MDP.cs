namespace XlsxMdpParser;

public class MDP
{
	public int Num { get; set; }

	public string Criteria { get; set; }
}
